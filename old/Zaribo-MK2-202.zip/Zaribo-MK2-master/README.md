# Zaribo-MK2(S) www.zaribo.org

Welcome to our new members and greetings to existing ones. Hereby you will find the expected clarification about Zaribo Project.

Zaribo 320 and Zaribo 220 are two options that you can mod your Original Prusa printers to. Numbers are indicating the Z Axis height. They are both featuring 3030 Aluminium Extrusions and improved plastic parts for rigidity, accuracy and speed. Both mods are almost identical except the Z Axis motors and rods. You need longer lead screws for 320 build and you can buy identical quality stepper motors from Zaribo.org which have been used on Original Prusa MK series

Zaribo.org is the web shop for high quality genuine parts you may need for your builds including screws, nuts, rambo boards and even extruder springs. You can also buy full upgrade kits which have everything you need to mod your Original Prusa.

Zaribo.org only sells tested, high quality genuine items. Misumi is the best and most affordable vendor so far for hardware like rods and extrusions. Rock hardened rods are being cut with lathe precision. Aluminum extrusion cutting and drilling are precise and without sawdust.

You can also find the BOM for Zaribo 320 and 220 on Zaribo.org/blog

Special thanks to all our members for the contribution as the project is growing within an exceptional friendly and courteous platform by our originator, caressing and smart members from all arround the world. 
